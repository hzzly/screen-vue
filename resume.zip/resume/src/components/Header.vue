<template>
    <div class="header">
        <div class="avatar">
            <a href="http://omt3u4bph.bkt.clouddn.com/avatar2.jpg" target="_blank">
                <img src="http://omt3u4bph.bkt.clouddn.com/avatar2.jpg" alt="">
            </a>
        </div>
        <p>基本信息</p>
        <div class="message_box">
            <ul>
                <li><i class="icon">&#xe620;</i>本科</li>
                <li><i class="icon">&#xe62d;</i>软件工程</li>
                <li><i class="icon">&#xe64d;</i>东华理工大学</li>
                <li><i class="icon">&#xe623;</i>2018.6</li>
            </ul>
        </div>
        <p>联系方式</p>
        <div class="message_box">
            <ul>
                <li>
                    <i class="icon">&#xe613;</i>18679168426</li>
                <li>
                    <i class="icon">&#xe648;</i>842250570</li>
                <li>
                    <i class="icon">&#xe724;</i>hjingren@aliyun.com</li>
                <li>
                    <i class="icon">&#xe602;</i><a href="https://hzzly.github.io/" target="_blank">技术博客</a>
                </li>
            </ul>
        </div>
        <p>活跃社区</p>
        <div class="message_box">
            <ul>
                <li>
                    <i class="icon">&#xeaf6;</i>
                    <a href="https://github.com/hzzly" target="_blank">Github</a>
                </li>
                <li>
                    <i class="icon" style="font-size: 12px">&#xe604;</i>
                    <a href="https://juejin.im/user/5787a6f9a633bd00584e9cc6" target="_blank">掘金</a>
                </li>
                <li>
                    <i class="icon">&#xe603;</i>
                    <a href="https://segmentfault.com/u/hzzly" target="_blank">Segmentfault</a>
                </li>
            </ul>
        </div>
        <p>奖项荣誉</p>
        <div class="message_box">
            <ul>
                <li>
                    <!--<i class="icon" style="font-size: 12px">&#xe604;</i>-->
                    1、2016年江西省大学生科技创新与职业技能竞赛二等奖
                </li>
                <li>
                    <!--<i class="icon">&#xe603;</i>-->
                    2、2016年江西省计算机作品大赛二等奖
                </li>
                <li>
                    <!--<i class="icon">&#xe603;</i>-->
                    3、校大学生科技创新基金项目一等奖
                </li>
                <li>
                    <!--<i class="icon">&#xeaf6;</i>-->
                    4、连续获学校三等奖学金
                </li>
            </ul>
        </div>
        <p>实习经历</p>
        <div class="message_box">
            <ul>
                <li>
                    <!--<i class="icon" style="font-size: 12px">&#xe604;</i>-->
                    1、点匠科技 <span>(2016.09-2016.12)</span>
                </li>
                <li>
                    <!--<i class="icon">&#xe603;</i>-->
                    2、南昌辰锦科技 <span>(2017.03-2017.05)</span>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.header {
    width: 300px;
    background: linear-gradient(rgba(180, 211, 196, 1), rgba(180, 211, 196, .5));
    // background: rgb(180, 211, 196);
    padding: 10px;
    // color: rgba(0, 0, 0, .3);
    color: #fff;
    .avatar {
        width: 180px;
        height: 215px;
        margin: 20px auto;
        img {
            width: 100%;
            display: block;
        }
    }
    p {
        margin-top: 30px;
        font-size: 16px;
        line-height: 40px;
        color: #f8f8f8;
    }
    .message_box {
        padding: 0 10px;
        ul {
            li {
                padding: 5px 0 0;
                font-size: 17px;
                color: #333;
                list-style: none;
                // cursor: pointer;
                .icon {
                    margin-right: 10px;
                }
                a {
                    color: #333;
                    &:hover {
                        color: #000;
                    }
                }
                span {
                    font-size: 14px;
                }
            }
        }
    }
}
</style>