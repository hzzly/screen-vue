<template>
    <div class="desc">
        <div class="title">自我描述</div>
        <div class="content-wrap">
            <p>热爱前端开发，追求新技术，代码格式规范强迫症。</p>
            <p>熟练掌握前端界面html5css3开发。能快速还原UI设计稿。</p>
            <p>熟练掌握vue编程 vue-cli vue-router vuex 单页应用(组件)开发。</p>
            <p>熟悉es5，es6语法。在两种语境下都有相应的编程经验。</p>
        </div>
    </div>
</template>

<style lang="scss" scoped>
.desc {
    margin-top: 20px;
    .content-wrap {
        margin: 20px 0 30px 5px;
    }
    p {
        line-height: 22px;
        margin-top: 10px;
    }
}
</style>