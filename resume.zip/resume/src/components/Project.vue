<template>
    <div class="project">
        <div class="title">项目经验</div>
        <ol>
            <li>
                <p>中包联盟(上线项目) <span>[2017.03-2017.05]</span></p>
                <ul>
                    <li>职责：前端开发与维护</li>
                    <li>PC官网2（Vue+Vue-Router）<a href="http://hzzly.net/league/" target="_blank">http://www.zblmchina.com</a></li>
                    <li>微信微官网（Vue+Vue-Router+Swiper）<a href="http://hzzly.net/league/m/" target="_blank">http://www.zblmchina.com/m/</a></li>
                    <li>PC端后台管理</li>
                    <li>微信端后台管理</li>
                </ul>
            </li>
            <li>
                <p>Vue音乐播放器(个人开源项目) <span>[2017.04-至今]</span></p>
                <ul>
                    <li>Vue全家桶、Scss、axios + Promise处理异步请求、es6、图片懒加载...</li>
                    <li>拆分各种组件</li>
                    <li>项目地址 <span style="font-weight: bold;">[110Stars]</span>：<a href="https://github.com/hzzly/MagicMusic" target="_blank">https://github.com/hzzly/MagicMusic</a></li>
                    <li>预览地址：<a href="http://hzzly.net/magic-music" target="_blank">http://hzzly.net/magic-music</a></li>
                </ul>
            </li>
            <li>
                <p>Qu约(个人开源项目) <span>[2016.07-2017.02]</span></p>
                <ul>
                    <li>v1.0版采用的技术栈是node+express+leancloud+handlebars实现的。</li>
                    <li>v2.0重构版 前端：vue+vue-router+vuex+axios</li>
                    <li>后端：node+express+leancloud提供api接口数据 前后端分离</li>
                    <li>分开制作了<a style="color: #000" href="https://github.com/hzzly/vue-datetime-picker" target="_blank">日期选择</a>、地址选择、加载loading、toast等可复用组件</li>
                    <li>项目地址 <span style="font-weight: bold;">[410Stars]</span>：<a href="https://github.com/hzzly/xyy-vue" target="_blank">https://github.com/hzzly/xyy-vue</a></li>
                    <li>预览地址：<a href="http://hzzly.net/xyy-vue" target="_blank">http://hzzly.net/xyy-vue</a></li>
                </ul>
            </li>
            <li>
                <p>点匠环保工程(上线项目) <span>[2016.09-2016.12]</span></p>
                <ul>
                    <li>职责：前端开发与维护</li>
                    <li>将原有的android、ios应用 配合后端工程师开发一套 微信产品, 前后端数据联调</li>
                    <li>使用了手淘的flexible+rem移动端适配方案,jquery+vue+weui,前后端分离,各种Vue组件</li>
                    <li>预览：<a href="http://www.dianjiang99.com/html/user_center/user_center.html" target="_blank">http://www.dianjiang99.com/html/user_center/user_center.html</a></li>
                    <li>(测试账号:15103585135 测试密码:123456)</li>
                </ul>
            </li>
        </ol>
    </div>
</template>

<style lang="scss" scoped>
.project {
    ol {
        margin-left: 20px;
        li {
            font-size: 18px;
            margin: 20px 0 10px;
            p {
                font-size: 18px;
                line-height: 40px;
                span {
                    font-size: 15px;
                    vertical-align: middle;
                }
            }
            ul {
                padding-left: 20px;
                li {
                    font-size: 16px;
                    margin: .5rem 0;
                    line-height: 24px;
                }
            }
        }
    }
}
</style>