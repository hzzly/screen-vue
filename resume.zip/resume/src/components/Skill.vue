<template>
    <div class="skill">
        <div class="title">个人技能</div>
        <ul>
            <li class="front">
                <p>前端</p>
                <ul>
                    <li>熟悉html css JavaScript(ES6) jQuery</li>
                    <li>具备前后端分离思想, 有过前端渲染经验</li>
                    <li>Vue Vuex VueRouter(有实战经验，可快速上手)</li>
                    <li>React Redux ReactRouter(了解学习过)</li>
                    <li>了解scss 微信小程序 前端自动化工具(webpack gulp)</li>
                </ul>
            </li>
            <li class="end">
                <p>后端</p>
                <ul>
                    <li>了解 node.js(express mongodb)</li>
                    <li>了解 php(thinkphp)</li>
                    <li>服务端渲染 有过服务端渲染模板的经验(MVC)</li>
                </ul>
            </li>
            <li class="group">
                <p>团队开发(版本管理)</p>
                <ul>
                    <li>Git</li>
                </ul>
            </li>
        </ul>
    </div>
</template>

<style lang="scss" scoped>
.skill {
    >ul {
        margin: 10px 0 20px;
        .front,
        .end,
        .group {
            list-style: none;
            ul {
                padding-left: 40px;
                li {
                    margin: .5rem 0;
                }
            }
            p {
                font-size: 18px;
                line-height: 40px;
            }
        }
    }
}
</style>