<template>
	<div id="app">
		<div class="resume-box">
			<v-header></v-header>
			<div class="content">
				<div class="name_box">
					<p>黄敬仁</p>
					<p>求职意向: 前端开发</p>
				</div>
				<v-skill></v-skill>
				<v-project></v-project>
				<v-desc></v-desc>
			</div>
		</div>
		<div class="footer">本简历使用Vue框架开发。更多联系方式请查看Props。<a href="http://hzzly.net/resume/">hzzly.net/resume/</a></div>
	</div>
</template>

<script>
import VHeader from './components/Header'
import VSkill from './components/Skill'
import VDesc from './components/Desc'
import VProject from './components/Project'

export default {
	name: 'app',
	components: {
		VHeader,
		VSkill,
		VDesc,
		VProject
	}
}
</script>

<style lang="scss">
* {
	margin: 0;
	padding: 0;

	box-sizing: border-box;
}

html,
body {
	background: #f8f8f8;
	font-size: 16px;
	font-family: "Microsoft Yahei", "Hiragino Sans GB", "Helvetica Neue", Helvetica, tahoma, arial, Verdana, sans-serif, "WenQuanYi Micro Hei";
}

ul li {
	list-style-type: circle;
}

@font-face {
  font-family: 'iconfont';  /* project id 295465 */
  src: url('//at.alicdn.com/t/font_aowx50fl1kw6d2t9.eot');
  src: url('//at.alicdn.com/t/font_aowx50fl1kw6d2t9.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_aowx50fl1kw6d2t9.woff') format('woff'),
  url('//at.alicdn.com/t/font_aowx50fl1kw6d2t9.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_aowx50fl1kw6d2t9.svg#iconfont') format('svg');
}

.icon {
	font-family: "iconfont" !important;
	font-size: 20px;
	font-style: normal;
	color: #ffffff;
}

#app {
	font-family: 'Avenir', Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	position: relative;
	.resume-box {
		width: 900px;
		height: auto;
		margin: 30px auto 10px;
		box-shadow: 0 0 40px #bdbdbd;
		position: relative;
		display: flex;
		.content {
			flex: 1;
			padding: 20px;
			.name_box {
				padding: 20px 0;
				p:first-child {
					font-size: 38px;
					line-height: 55px;
				}
				p:last-child {
					color: rgba(0, 0, 0, .8);
					font-size: 18px;
				}
			}
		}
	}
	.footer {
		text-align: center;
		font-size: 14px;
		line-height: 40px;
	}
}

.title {
	font-size: 22px;
	padding-bottom: 10px;
	border-bottom: 1px solid #B4D3C4;
}
</style>
